%% Implementation of the Reweighted Amplitude Flow algorithm proposed in the paper
%  `` Solving Almost Systems of Random Quadratic Equations
%  by G. Wang, G. B. Giannakis, Y. Saad, and J. Chen.
%  The code below is adapted from implementation of the Wirtinger Flow
% algorithm implemented by E. Candes, X. Li, and M. Soltanolkotabi.

function Error = RAF(y_int, x, x0, Params, Amatrix)

ymag    = sqrt(y_int);
z = x0;
m       = Params.m;

% Params.muRAF         = 2 * (1 - Params.cplx_flag) + 5 * Params.cplx_flag;  % default
Params.muRAF         = 2 * (1 - Params.cplx_flag) + 4 * Params.cplx_flag;
Params.eta           = 10;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

z_old = zeros(length(x),1);

for t = 1: Params.T
    
    Az    = Amatrix * z; 
    ratio = abs(Az) ./ ymag;
    ang   = Params.cplx_flag * exp(1i * angle(Az)) + (1 - Params.cplx_flag) * sign(Az);
    grad  = Amatrix' * ((ymag .* ang - Az) .* (ratio ./ (ratio + Params.eta))) / m;
    z     = z + Params.muRAF * grad;
    
    Error.MSE(t) = norm(x - exp(-1i*angle(trace(x'*z))) * z, 'fro')^2/norm(x,'fro')^2;
    Error.Alpha(t) = abs( x'*z/norm(x)^2 ) ;
    Error.Sigma2(t) = norm( z - x'*z/norm(x)^2 * x )^2/norm(x)^2; 
    
    %% stopping condition
    if norm(z-z_old)^2/norm(z)^2 < Params.stop_tol
        Error.MSE(t+1:Params.T) = Error.MSE(t);
        Error.Alpha(t+1:Params.T) = Error.Alpha(t);
        Error.Sigma2(t+1:Params.T) = Error.Sigma2(t);
        break;
    end
    z_old = z;
    
    if Params.show_hist
        fprintf('it = %d, alpha = %e, sigma2 = %e\n',t,Error.Alpha(t),Error.Sigma2(t));
    end
    
end


