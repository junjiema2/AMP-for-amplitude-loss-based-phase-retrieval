%% Gerchberg-Saxton algorithm

% Note: y = (Ax).^2
% (1) Left multipy the current estimation x by the measurement
%  matrix A and get Ax. 
% (2) Keep phase, update the magnitude using the
%  measurements b0, z = b0.*sign(Ax). 
% (3) Solve the least-squares problem
%           sol = \argmin ||Ax-z||^2
%      to get our new estimation x. We use Matlab built-in solver lsqr()
%      for this least square problem.

function Error = GS(y, x, x0, Params, Amatrix)    

% parameters for least square solver
tol = 1e-10;
maxit = 500;

y = sqrt(y);  % magnitude

Error.MSE = zeros(Params.T,1);
Error.Alpha = zeros(Params.T,1);
Error.Sigma2 = zeros(Params.T,1);

z_old = zeros(length(x),1);

z = x0; 

B = (Amatrix'*Amatrix+1e-8*eye(length(z)))^(-1) * Amatrix';
for t = 1: Params.T
    
    % Initialization
                    % Initial Guess

    b = y.*sign(Amatrix * z); % Calculate the initial spectral magnitude.
    
%     z = Amatrix\b;
%     z = lsqr(Amatrix,b,tol,maxit); 
    z = B * b;
    
    Error.MSE(t) = norm(x - exp(-1i*angle(trace(x'*z))) * z, 'fro')^2/norm(x,'fro')^2;
    Error.Alpha(t) = abs( x'*z/norm(x)^2 ) ;
    Error.Sigma2(t) = norm( z - x'*z/norm(x)^2 * x )^2/norm(x)^2;
    
    %% stopping condition
    if norm(z-z_old)^2/norm(z)^2 < Params.stop_tol
        Error.MSE(t+1:Params.T) = Error.MSE(t);
        Error.Alpha(t+1:Params.T) = Error.Alpha(t);
        Error.Sigma2(t+1:Params.T) = Error.Sigma2(t);
        break;
    end
    
    z_old = z;
    
    if Params.show_hist
        fprintf('it = %d, alpha = %e, sigma2 = %e\n',t,Error.Alpha(t),Error.Sigma2(t));
    end
    
end
