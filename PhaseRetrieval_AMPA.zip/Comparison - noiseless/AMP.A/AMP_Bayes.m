%% Bayes-optimal AMP for Gaussian signal

function [Error] = AMP_Bayes(y_int, x, x0, Params, Amatrix)    

delta = Params.delta;
n = length(x);

%% initialization
if strcmp(Params.init_opt,'positive')
    alpha_0 = Params.init_scale * sqrt(Params.epsilon);
    sigma2_0 = Params.init_scale^2 - alpha_0^2;
    tau = nan;
else
    [tau,alpha_0] = Spectral_SE(Params);
    sigma2_0 = 1 - alpha_0^2;
    ytr = trim(y_int, Params); %
end

x_hat = x0; % now x0 is the output of power method

%% TODO: State evolution
% Results =  StateEvolution(Params,alpha_0,sigma2_0);

% SE_out.Alpha = Results.Alpha;
% SE_out.Sigma2 = Results.Sigma2;
% SE_out.Dif_p = Results.Dif_p;
% SE_out.alpha0 = alpha_0;
% SE_out.tau = tau;

Error.Alpha = zeros(Params.T,1);
Error.Sigma2 = zeros(Params.T,1);
Error.MSE = zeros(Params.T,1);

%% AMP iterations
% data pre-processing: to be consistent with the normalization used in our
% paper
scaling = sqrt( 1/norm(Amatrix,'fro')^2 * length(x) );

% test
y = sqrt(y_int) * scaling;
A = Amatrix * scaling;  % E[A_ij^2] = 1/m

x_hat_old = zeros(length(x),1);

%% preprocessing: notice that we don't need to change p^0

% not much difference whether we do this scaling or not

M = length(y);

C = alpha_0/(alpha_0^2+sigma2_0);
x_hat = C * x_hat;
x0 = C * x0;

s_hat = zeros(M,1);

%------------------------- handle variance option -----------------

if Params.Bayes_uniform_var == 'N'
    A2 = abs(A).^2;
    v_z = sigma2_0/(alpha_0^2 + sigma2_0) * ones(n,1);
else
    v_z = sigma2_0/(alpha_0^2 + sigma2_0); % effective noise
end


for it = 1: Params.T
    %% real
    if Params.Bayes_uniform_var == 'N'
        v_p = A2 * v_z;   % column normalization
    else
        v_p = 1/delta * v_z;   % column normalization
    end

    if it == 1 
        if Params.spectral_correct & ~strcmp(Params.init_opt,'positive') % proposed correction
            p_hat = (1-2*tau * ytr) .* (A * x_hat);
        elseif strcmp(Params.init_opt,'positive')
            p_hat = A * x_hat;  % positive signal
        else % blind
            p_hat = A * x_hat;
        end
    else
        p_hat = A * x_hat - v_p .* s_hat;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if Params.cplx_flag == 0  % real-valued
        z_A_post = y .* tanh( y.*p_hat ./ v_p );
        div = abs(y).^2 ./ v_p .* ( 1 - tanh( y.*p_hat ./ v_p ).^2 );
        VAR_A = div .* v_p;
    else        % complex-valued
        if strcmp(Params.Bayes_div,'CondVar') % conditional variance, used in the GAMP phase retrieval paper
            rho_m = 2 * y .* abs(p_hat) ./ ( v_p);
            R0 = besseli(1,rho_m,1) ./ besseli(0,rho_m,1);
            p_hat_phase = sign(p_hat);
            z_A_post = ( y .* R0 ) .* p_hat_phase; 
            VAR_A = abs(y).^2 - abs(z_A_post).^2;
        elseif strcmp(Params.Bayes_div,'Wirtinger') % Wirtinger derivative, slightly better than conditional var
            
            rho_m = 2 * y .* abs(p_hat) ./( v_p);
            R0 = besseli(1,rho_m,1) ./ besseli(0,rho_m,1);
            I0 = besseli(0,rho_m,1);
            I1 = besseli(1,rho_m,1);
            I2 = besseli(2,rho_m,1);
            NUM = 0.5 * (I0 + I2).*I0 - I1.^2;
            DEN = I0.^2;
            R0_dif = NUM./DEN .* (2*y./v_p);
            F_dif = y.*( R0_dif + R0./(2*abs(p_hat)) );

            p_hat_phase = sign(p_hat);
            z_A_post = ( y .* R0 ) .* p_hat_phase;         
            VAR_A = y.*( NUM./DEN .* (2*y) + v_p.*R0./(2*abs(p_hat)) );
        end
    end
    %%%--------------------------------------
    % update s
    s_hat = ( z_A_post - p_hat ) ./ v_p;
    v_s = ( 1 - VAR_A ./ v_p ) ./ v_p; 
    v_s = max(v_s,Params.VarClipping);
    % step 4
    if Params.Bayes_uniform_var == 'N'
        v_r = 1 ./ (A2.' * v_s);
    else
        v_s = mean(v_s);  % average
        v_r = 1/v_s;  % columna normalization
    end
    r_hat = x_hat + v_r .* ( A' * s_hat ); %

    % step 5
    x_hat = 1./(1+v_r) .* r_hat;
    v_z = v_r ./ ( 1 + v_r );

    v_z = max(v_z,Params.VarClipping);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %% accuracy
    Error.MSE(it) = norm(x - exp(-1i*angle(trace(x'*x_hat))) * x_hat, 'fro')^2/norm(x,'fro')^2;
    Error.Alpha(it) = abs( x'*x_hat/norm(x)^2 ) ;
    Error.Sigma2(it) = norm( x_hat - x'*x_hat/norm(x)^2 * x )^2/norm(x)^2; 
    
    %% stopping condition
    if norm(x_hat - x_hat_old)^2/norm(x_hat)^2 < Params.stop_tol
        Error.MSE(it+1:Params.T) = Error.MSE(it);
        Error.Alpha(it+1:Params.T) = Error.Alpha(it);
        Error.Sigma2(it+1:Params.T) = Error.Sigma2(it);
        break;
    end
    
    x_hat_old = x_hat;

    if Params.show_hist
        fprintf('it = %d\n',it);
        fprintf('simulation: alpha = %e, sigma2 = %e\n',Error.Alpha(it),Error.Sigma2(it));
    end

end
