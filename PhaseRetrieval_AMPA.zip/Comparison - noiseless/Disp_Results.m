function Disp_Results(ErrMea,Params,SE_results)

    fpath = [pwd,'/results'];
    
    delta = Params.delta;
    n = Params.n1;
    NSIM = Params.NSIM;
    T = Params.T;
    
    % fontsize and linewidth
    FontSizeMy = 14;
    LineWidthMy = 1.5;
    
    % save data
    if Params.saveResults
        Name = ['data.mat'];
        save(fullfile(fpath,Name),'ErrMea','Params','SE_results');
    end
    
    Colors = {'r','g','b','m','c','k','r--','b--','k--','r.','b.','k.'} ;
    if length(Params.Methods)>length(Colors)
        fprintf('too many methods\n');
        return;
    end
    
 
    
    %%-------------------------- plot for multiple delta points -----------
    if length(Params.delta_grid) > 1
        
        % aveage MSE
        figure;
        for i = 1:length(Params.Methods)
            semilogy(Params.delta_grid,ErrMea.MSE_ave(:,i), Colors{i} ,'LineWidth',LineWidthMy);
            hold on;
        end
        hold off;
        xlabel('delta');
        ylabel('MSE');
        set(gca,'fontsize',FontSizeMy);
        legend(Params.Methods,'fontsize',FontSizeMy);

        Name = ['MSE_all','_N',num2str(n),'_NSIM',num2str(Params.NSIM),'.fig'];
        if Params.saveResults
            saveas(gcf,fullfile(fpath,Name) );
            close;
        end
        
        % success rate
        figure;
        for i = 1:length(Params.Methods)
            plot(Params.delta_grid,ErrMea.SuccessRate(:,i), Colors{i} ,'LineWidth',LineWidthMy);
            hold on;
        end
        hold off;
        xlabel('delta');
        ylabel('success rate');
        set(gca,'fontsize',FontSizeMy);
        legend(Params.Methods,'fontsize',FontSizeMy);

        Name = ['SuccessRate_all_methods','_N',num2str(n),'_NSIM',num2str(Params.NSIM),'.fig'];
        if Params.saveResults
            saveas(gcf,fullfile(fpath,Name) );
            close;
        end
        
        return;
    end
    
    %%--------------------------- plot for a single delta -----------------
    
    % compare MSEs
    figure;
    for i = 1:length(Params.Methods)
        semilogy(1:T,ErrMea.MSE_ave(:,i), Colors{i} ,'LineWidth',LineWidthMy);
        hold on;
    end
    hold off;
    xlabel('iteration');
    ylabel('MSE');
    set(gca,'fontsize',FontSizeMy);
    legend(Params.Methods,'fontsize',FontSizeMy);
    
    Name = ['MSE_all','_delta',num2str(delta),'_N',num2str(n),'_NSIM',num2str(Params.NSIM),'.fig'];
    if Params.saveResults
        saveas(gcf,fullfile(fpath,Name) );
        close;
    end
    
    % results of AMP
    if Params.showSE
        
        for i = 1:length(Params.Methods)
            
            if ~strcmp(Params.Methods{i},'AMP.A') & ~strcmp(Params.Methods{i},'AMP.A-blind')
                continue;
            end
            
            % all trials: alpha
            figure;
            plot(1:T,SE_results.Alpha, 'b.' ,'LineWidth',LineWidthMy);
            for nsim = 1:NSIM
                hold on;
                plot(1:T,ErrMea.Alpha(:,i,nsim), 'r' ,'LineWidth',LineWidthMy);
            end
            hold off;
            
            xlabel('iteration');
            ylabel('alpha');
            legend('SE prediction','simulation');
            set(gca,'fontsize',FontSizeMy);
            
            Name = ['Alpha_AMP','_delta',num2str(delta),'_N',num2str(n),'_NSIM',num2str(Params.NSIM),'.fig'];
            if Params.saveResults
                saveas(gcf,fullfile(fpath,Name) );
                close;
            end

            % all trials: sigma2
            figure;
            semilogy(1:T,SE_results.Sigma2, 'b.' ,'LineWidth',LineWidthMy);
            for nsim = 1:NSIM
                hold on;
                semilogy(1:T,ErrMea.Sigma2(:,i,nsim), 'r' ,'LineWidth',LineWidthMy);
            end
            hold off;
            
            xlabel('iteration');
            ylabel('sigma2');
            legend('SE prediction','simulation');
            set(gca,'fontsize',FontSizeMy);
            
            Name = ['Sigma2_AMP','_delta',num2str(delta),'_N',num2str(n),'_NSIM',num2str(Params.NSIM),'.fig'];
            if Params.saveResults
                saveas(gcf,fullfile(fpath,Name) );
                close;
            end

            % average: alpha
            figure;
            plot(1:T,SE_results.Alpha,'b.',...
                1:T,ErrMea.Alpha_ave(:,i),'r','LineWidth',LineWidthMy);

            xlabel('iteration');
            ylabel('alpha');
            legend('SE prediction','simulation');
            set(gca,'fontsize',FontSizeMy);
            
            Name = ['Alpha_AMP_ave','_delta',num2str(delta),'_N',num2str(n),'_NSIM',num2str(Params.NSIM),'.fig'];
            if Params.saveResults
                saveas(gcf,fullfile(fpath,Name) );
                close;
            end

            % average: alpha
            figure;
            semilogy(1:T,SE_results.Sigma2, 'b.',...
                1:T,ErrMea.Sigma2_ave(:,i),'r' ,'LineWidth',LineWidthMy);

            xlabel('iteration');
            ylabel('sigma2');
            legend('SE prediction','simulation');
            set(gca,'fontsize',FontSizeMy);
            
            Name = ['Sigma2_AMP_ave','_delta',num2str(delta),'_N',num2str(n),'_NSIM',num2str(Params.NSIM),'.fig'];
            if Params.saveResults
                saveas(gcf,fullfile(fpath,Name) );
                close;
            end

        end
        
    end
    
end