%% Plain amplitude flow. Codes adpated from the PhasePack package

function Error = AF(y_int, x, x0, Params, A, At, opts)  

    z = x0;
    y = sqrt(y_int);  % amplitude 

    m           = Params.m; 
    
    opts = manageOptions(opts);
    
    innerOpts = struct;
    innerOpts.maxIters = opts.maxIters;
    innerOpts.maxTime = opts.maxTime;
    innerOpts.tol = opts.tol;
    innerOpts.verbose = opts.verbose;
    innerOpts.recordTimes = opts.recordTimes;
    innerOpts.recordResiduals = opts.recordResiduals;
    innerOpts.recordMeasurementErrors = opts.recordMeasurementErrors;
    innerOpts.recordReconErrors = opts.recordReconErrors;
    innerOpts.xt = opts.xt;
    
    innerOpts.searchMethod = opts.searchMethod;
    innerOpts.betaChoice = opts.betaChoice;
    

    [z, outs] = gradientDescentSolver(A, At, x0, y, @updateObjective, innerOpts);

    function [f, gradf] = updateObjective(~, ~)
        f = @(z) 1/2 * norm(abs(z) - y)^2;
        gradf = @(z) (z - y .* sign(z));
    end

    Error.MSE(1:Params.T) = norm(x - exp(-1i*angle(trace(x'*z))) * z, 'fro')^2/norm(x,'fro')^2;
    Error.Alpha(1:Params.T) = abs( x'*z/norm(x)^2 ) ;
    Error.Sigma2(1:Params.T) = norm( z - x'*z/norm(x)^2 * x )^2/norm(x)^2; 
end