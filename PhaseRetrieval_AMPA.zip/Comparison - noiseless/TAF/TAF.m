

function Error = TAF(y, x, x0, Params, Amatrix)    

Params.mu            = 0.6 * (1 - Params.cplx_flag) + .9 * Params.cplx_flag; % step size / learning parameter
Params.gamma_lb      = .7;    %thresholding of throwing small entries of Az 0.3 is a good one

z = x0;

normest = sqrt(sum(y(:)) / numel(y(:)));    % Estimate norm to scale eigenvector
m       = Params.m;

Arnorm  = sqrt(sum(abs(Amatrix).^2, 2)); % norm of rows of Amatrix
ymag    = sqrt(y);
ynorm   = ymag ./ (Arnorm .* normest);

%% finding the angle of inner prodcut

Anorm      = bsxfun(@rdivide, Amatrix, Arnorm);
[ysort, ~] = sort(ynorm, 'ascend');
ythresh    = ysort(round(Params.m / (6/5))); % 6/5 the orthogonality-promoting initialization parameter
ind        = (abs(ynorm) >= ythresh);

Error.MSE = zeros(Params.T,1);
Error.Alpha = zeros(Params.T,1);
Error.Sigma2 = zeros(Params.T,1);

z_old = zeros(length(x),1);

for t = 1: Params.T
    
    Az    = Amatrix * z; %A(z);
    ratio = abs(Az) ./ ymag;
    yz    = ratio > 1 / (1 + Params.gamma_lb);
    ang   = Params.cplx_flag * exp(1i * angle(Az)) + (1 - Params.cplx_flag) * sign(Az);
    
    grad  = Amatrix' * (yz .* ymag .* ang - yz .* Az) / m;
    z     = z + Params.mu * grad;
    
    Error.MSE(t) = norm(x - exp(-1i*angle(trace(x'*z))) * z, 'fro')^2/norm(x,'fro')^2;
    Error.Alpha(t) = abs( x'*z/norm(x)^2 ) ;
    Error.Sigma2(t) = norm( z - x'*z/norm(x)^2 * x )^2/norm(x)^2;
    
    %% stopping condition
    if norm(z-z_old)^2/norm(z)^2 < Params.stop_tol
        Error.MSE(t+1:Params.T) = Error.MSE(t);
        Error.Alpha(t+1:Params.T) = Error.Alpha(t);
        Error.Sigma2(t+1:Params.T) = Error.Sigma2(t);
        break;
    end
    z_old = z;
    
    if Params.show_hist
        fprintf('it = %d, alpha = %e, sigma2 = %e\n',t,Error.Alpha(t),Error.Sigma2(t));
    end
    
end
