% The code is for the paper "Reshaped Wirtinger flow and Incremental Algorithms for Solving Quadratic Systems of Equations" by H. Zhang, Y. Zhou, Y. Liang and Y. Chi.
% see https://github.com/hubevan/reshaped-Wirtinger-flow

function Error = IRWF(y_int, x, x0, Params, Amatrix)  

z = x0;
y = sqrt(y_int);  % amplitude 

m           = Params.m; 

mu=1;
sgd=Params.m;
batch=64; %batch=1 if for IRWF, 

z_old = zeros(length(x),1);

for t = 1:Params.T
    
    for i=1:batch:sgd-batch+1

        Asub=Amatrix(i:i+batch-1,:);
        ysub=y(i:i+batch-1);
        Asubz=Asub*z;
        z=z-(Asub'*(Params.n1\(Asubz-ysub.*Asubz./abs(Asubz))));
    end

    Error.MSE(t) = norm(x - exp(-1i*angle(trace(x'*z))) * z, 'fro')^2/norm(x,'fro')^2;
    Error.Alpha(t) = abs( x'*z/norm(x)^2 ) ;
    Error.Sigma2(t) = norm( z - x'*z/norm(x)^2 * x )^2/norm(x)^2; 
    
    %% stopping condition
    if norm(z-z_old)^2/norm(z)^2 < Params.stop_tol
        Error.MSE(t+1:Params.T) = Error.MSE(t);
        Error.Alpha(t+1:Params.T) = Error.Alpha(t);
        Error.Sigma2(t+1:Params.T) = Error.Sigma2(t);
        break;
    end
    z_old = z;
    
    if Params.show_hist
        fprintf('it = %d, alpha = %e, sigma2 = %e\n',t,Error.Alpha(t),Error.Sigma2(t));
    end

end

