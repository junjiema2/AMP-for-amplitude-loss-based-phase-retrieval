%% Noisy Phase retrieval: only for AMP
%  Model: y = |Ax| + n
%  x has positive entries; initial estimate: all-ones vector

   
function Noisy_AMP

    clear all;
    clc ;
    close all;

    addpath( genpath(pwd) );

    %% parameters  

    Params.n1          = 5000; 
    Params.delta_grid = linspace(4,4,1);
    Params.init_opt  = 'positive'; % {'optimal','truncation','subset', 'positive'}    % "positive" for positive signal
    Params.init_scale  = 1; % scaling to the all ones vector
    
    Params.SNRdB = 30;  % norm(Ax)^2/norm(w)^2; w is the measurement noise
    
    Params.eig = 'eigs';  % power, eigs
    Params.epsilon = 0.1;  % sparsity
    Params.npower_iter = 300; % number of power iterations
    Params.NSIM        = 10; 
    Params.cplx_flag   = 1;  % real: cplx_flag = 0;  complex: cplx_flag = 1;
    Params.T           = 50;  % number of iteration
    
    if Params.init_scale && ~strcmp(Params.init_opt,'positive')
        fprintf('to be safe in the noiseless case, scale it. not done yet\n');
        pause;
    end
    
    
    Params.MSE_tol     = 1e-10;
    Params.stop_tol    = 1e-20;  % stopping condition

    Params.saveResults = 1; %
    % show opt
    Params.show_hist   = 0; % show history
    if Params.n1^2 > 5*10^7
        Params.show_hist   = 1; % show history
    end
    
    Params.showSE = 1;
    
    % parameters for AMP
    Params.tau_acurracy = 'medium'; % low medium high
    
    if Params.cplx_flag
        
        Params.div_SE = 0; % default for complex
    
    end
    % still using pre-computed SE is good is the complex-valued case for
    % small system
    
    if ~Params.div_SE
        Params.Smooth = 1; % one step smooth for real-valued
    end
    
    n           = Params.n1;    
     
    cplx_flag	= Params.cplx_flag;  % real-valued: cplx_flag = 0;  complex-valued: cplx_flag = 1;  
    
%     Params.Methods   = {'TWF','IRWF','TAF','RAF', 'GS','AMP.A'} ; 
%     Params.Methods   = {'AMP.A','IRWF','GS','TAF','RAF','TWF','AF','PhaseMax'} ;

    Params.Methods   = {'AMP.A'} ;
    nMethods = length(Params.Methods);
    
    % error measure
    if length(Params.delta_grid) > 1 % if multiple delta points, display average results
        delta_grid = Params.delta_grid;
        ErrMea.MSE_ave = zeros(length(delta_grid),nMethods);
        ErrMea.Alpha_ave = zeros(length(delta_grid),nMethods);
        ErrMea.Sigma2_ave = zeros(length(delta_grid),nMethods);
        ErrMea.SuccessRate = zeros(length(delta_grid),nMethods);
    else  % display error for all runs
        ErrMea.MSE = zeros(Params.T,nMethods,Params.NSIM);
        ErrMea.Alpha = zeros(Params.T,nMethods,Params.NSIM);
        ErrMea.Sigma2 = zeros(Params.T,nMethods,Params.NSIM);
        ErrMea.MSE_ave = zeros(Params.T,nMethods);
        ErrMea.Alpha_ave = zeros(Params.T,nMethods);
        ErrMea.Sigma2_ave = zeros(Params.T,nMethods);
    end
    
    % for AMP
    SE_results.alpha_0 = 0;  % initial
    SE_results.tau = 0;
    SE_results.MSE = zeros(Params.T,1);
    SE_results.Alpha = zeros(Params.T,1);
    SE_results.Sigma2 = zeros(Params.T,1);
    SE_results.Dif_p = zeros(Params.T,1);
    
    %% simuation
    for ddd = 1:length(Params.delta_grid)
        
        rand('state',0);
        randn('state',0);
        
        Params.delta       = Params.delta_grid(ddd);
        Params.m           = fix( Params.delta * Params.n1 );  % number of measurements
        m = Params.m;
        delta = Params.delta;
        
        x = zeros(n,1);
        y = zeros(m,1);
        Amatrix = zeros(m,n);

        for nsim = 1:Params.NSIM

            % data generation
            if strcmp(Params.init_opt,'positive')
                index = randperm(n);
                x = zeros(n,1);
                k = ceil(Params.epsilon * n);
                x(index(1:k)) = sqrt(1/Params.epsilon);
            else
                x = ( randn(n,1) + 1i * Params.cplx_flag * randn(n,1) ) / sqrt( 2^Params.cplx_flag ); % 
            end
            
            Amatrix = (randn(m,n) + 1i * Params.cplx_flag * randn(m,n)) / sqrt( 2^Params.cplx_flag);       
            
%             % Other normalization is also permitted
%             x = x * 2;
%             Amatrix = Amatrix * 2;
            
            A  = @(I) Amatrix  * I;
            At = @(Y) Amatrix' * Y;
            
            y_mag = abs( A(x) );  % NOTE: magnitude, not intensity

            sigma2_w = norm(y_mag)^2/length(y_mag) * 10^(-Params.SNRdB/10);
            
            y_mag = y_mag + sqrt(sigma2_w) * ...
                ( randn(m,1) + 1i * Params.cplx_flag * randn(m,1) ) / sqrt( 2^Params.cplx_flag ); % 
            
            % Initialization
            if strcmp(Params.init_opt,'positive')
                x0 = Params.init_scale * ones(n,1);
            else
                fprintf('to be completed\n');
                pause
            end

            fprintf('delta = %.2f, trial = %d\n',delta,nsim);

            % different methods 

            for methods_cnt = 1:length(Params.Methods)

                alg_opt = Params.Methods{methods_cnt};

                switch alg_opt
%                     case 'TWF'
%                         Error = TWF(y, x, x0, Params, A, At); 
%                     case 'IRWF'
%                         Error = IRWF(y, x, x0, Params, Amatrix); 
%                     case 'TAF'
%                         Error = TAF(y, x, x0, Params, Amatrix);
%                     case 'RAF'
%                         Error = RAF(y, x, x0, Params, Amatrix);
                    case 'AMP.A' % proposed correction to spectral initialization
                        Params.spectral_correct = 1; 
                        [Error,SE_results] = AMP_mag(y_mag, x, x0, Params, Amatrix);
%                     case 'AMP.A-blind'  % no correction to spectral initialization
%                         Params.spectral_correct = 0; 
%                         [Error,SE_results] = AMP(y_mag, x, x0, Params, Amatrix);
%                     case 'GS' 
%                         [Error] = GS(y, x, x0, Params, Amatrix);
%                     case 'AF' 
%                         % Options
%                         opts = struct;
% %                         opts.initMethod = 'optimal';
%                         opts.algorithm = 'AmplitudeFlow';
%                         opts.isComplex = 1;
%                         opts.maxIters = Params.T;
%                         opts.tol = 1e-6;
%                         opts.xt = [];
%                         opts.verbose = 0;
%                         [Error] = AF(y, x, x0, Params, A, At, opts);
%                     case 'PhaseMax' 
%                         opts = struct;
%                         opts.isComplex = 1;
%                         opts.maxIters = Params.T;
%                         opts.tol = 1e-6;
%                         opts.xt = [];
%                         opts.verbose = 0;
%                         [Error] = PhaseMax(y, x, x0, Params, A, At, opts);
                        
%                         a = 1;
                    otherwise
                        fprintf('unknown algorithm option\n');
                        pause;
                end

                if length(Params.delta_grid) > 1
                    ErrMea.MSE_ave(ddd,methods_cnt) = (nsim-1)/nsim * ErrMea.MSE_ave(ddd,methods_cnt) + Error.MSE(end)/nsim;
                    ErrMea.Alpha_ave(ddd,methods_cnt) = (nsim-1)/nsim * ErrMea.Alpha_ave(ddd,methods_cnt) + Error.Alpha(end)/nsim;
                    ErrMea.Sigma2_ave(ddd,methods_cnt) = (nsim-1)/nsim * ErrMea.Sigma2_ave(ddd,methods_cnt) + Error.Sigma2(end)/nsim;
                    ErrMea.SuccessRate(ddd,methods_cnt) = (nsim-1)/nsim * ErrMea.SuccessRate(ddd,methods_cnt)...
                        + ( Error.MSE(end) < Params.MSE_tol ) /nsim;
                    fprintf('%11s: MSE = %e, SuccessRate = %.3f\n',Params.Methods{methods_cnt},ErrMea.MSE_ave(ddd,methods_cnt),...
                        ErrMea.SuccessRate(ddd,methods_cnt) );
                else
                    ErrMea.MSE(:,methods_cnt,nsim) = Error.MSE;
                    ErrMea.Alpha(:,methods_cnt,nsim) = Error.Alpha;
                    ErrMea.Sigma2(:,methods_cnt,nsim) = Error.Sigma2;
                    fprintf('%11s: %e\n',Params.Methods{methods_cnt},Error.MSE(end));
                end
            end

            fprintf('\n');
        end
    
    end
    
    if length(Params.delta_grid) == 1
        ErrMea.MSE_ave = mean(ErrMea.MSE,3);
        ErrMea.Alpha_ave = mean(ErrMea.Alpha,3);
        ErrMea.Sigma2_ave = mean(ErrMea.Sigma2,3);
    end
    
    % display and save results
    Disp_Results(ErrMea,Params,SE_results);

    fprintf('---------------------------------------------\n');
    if Params.saveResults
        fprintf('completed! data saved in folder "results"\n');
    else
        fprintf('completed!\n');
    end
    fprintf('---------------------------------------------\n');

end