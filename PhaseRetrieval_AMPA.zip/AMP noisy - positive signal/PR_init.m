%% initialization. Code adpated from the PhasePack package.

% y = |Ax|.^2
function x0 = PR_init(y, Params, Amatrix)

    npower_iter = Params.npower_iter;           % Number of power iterations 
    z0 = randn(Params.n1,1) + 1i * Params.cplx_flag * randn(Params.n1,1);  
    z0 = z0/norm(z0,'fro');    % Initial guess 
    
    % handle general matrix normalization
    Power_entry = sum(y)/norm(Amatrix,'fro')^2;  % signal power per entry
    normest = sqrt( Power_entry * Params.n1 );
    
    delta = Params.delta;

    %% normalization, otherwise epsilon should be adapted to the size of A
    scaling = sqrt( 1/norm(Amatrix,'fro')^2 * length(z0) );
    A = Amatrix * scaling;  % E[A_ij^2] = 1/m
    y = y * scaling^2; % y is intensity
    
    %% trimming 
    ytr = trim(y, Params);

    if strcmp(Params.eig,'power')
        
        %% power iteration
        error_rel = 0;
        for tt = 1:npower_iter,  

            z0_new = A'* ( ytr.* (A * z0) );

            if strcmp(Params.init_opt,'optimal') % to find the largest signed eigenvalue
               epsilon = 5;  %% should be a large number, but not too large. Otherwise convergence is slow
               z0_new = z0_new + epsilon * z0;
            end

            z0_new = z0_new/norm(z0_new,'fro');

            error_rel = norm(z0_new - z0)/norm(z0);
            if error_rel < 1e-5
                break
            end

            z0 = z0_new;
        end

        if error_rel > 1e-3
            fprintf('power method not converged!: error = %e\n',error_rel);
        end
        
    elseif strcmp(Params.eig,'eigs')
        
        % Build the function handle associated to the matrix Y
        Yfunc = @(x) 1/length(ytr) * Amatrix'* (ytr.* ( Amatrix * x) );

        % Our implemention uses Matlab's built-in function eigs() to get the leading
        % eigenvector because of greater efficiency.
        % Create opts struct for eigs
    
        opts = struct;
        opts.isreal = ~Params.cplx_flag;

        % Get the eigenvector that corresponds to the largest eigenvalue of the
        % associated matrix of Yfunc.
        [z0,~] = eigs(Yfunc, length(z0), 1, 'lr', opts);
    end

    x0 = normest * z0;                   % Apply scaling 
    
end