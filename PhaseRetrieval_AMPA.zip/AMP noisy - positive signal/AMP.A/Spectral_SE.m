% compute the fixed point of the spectral method

function [tau,alpha] = Spectral_SE(Params)

if strcmp(Params.tau_acurracy,'high')
    MM = 5e6;
elseif strcmp(Params.tau_acurracy,'medium')
    MM = 5e5;
elseif strcmp(Params.tau_acurracy,'low')
    MM = 1e5;
end

delta = Params.delta;

z = sqrt(1/delta) * ( randn(MM,1) + 1i * Params.cplx_flag * randn(MM,1) ) / sqrt( 2^Params.cplx_flag );

y_amp = abs(z); % amplitude

y_int = y_amp.^2; % intensity

%% trimming
T_y = trim(y_int, Params);
 
% compute the fixed point of tau1: bisection
T_max = max(T_y);  % this gives an upper bound for searching tau

if T_max > 1e4
    fprintf('T not upper bounded, violating assumptions');
    pause;
end

tau_max = 1/(2*T_max);  % this is not correct!!
%     tau_max = 100;
tau_min = 0;
tau_star = (tau_max + tau_min)/2;
it = 1;
while abs(tau_max - tau_min) > 1e-10
    fun_tmp = (  2 * tau_star * T_y./( 1 - 2 * tau_star * T_y ) ).^2;
    f_tmp = mean( fun_tmp );
    if f_tmp < 1/delta
        tau_min = tau_star;
    else
        tau_max = tau_star;
    end
    if abs(f_tmp - 1/delta) < 1e-5 | (it > 1000)
        break;
    end
    tau_star = (tau_max + tau_min)/2;   
    it = it + 1;
end


% test if phase transition happends
fun1_tmp = delta * abs(z).^2 .* T_y./ ( 1 - 2 * tau_star * T_y ) - T_y./ ( 1 - 2 * tau_star * T_y );
f_tmp = mean(fun1_tmp) - 1/(2*tau_star*delta);
if f_tmp < 0
    fprintf('delta below phase transition\n');
    pause;
end
%% compute tau

tau_max = tau_star;
tau_min = 0;
tau = (tau_max + tau_min)/2;
it = 1;
while abs(tau_max - tau_min) > 1e-10
    fun1_tmp = delta * abs(z).^2 .* T_y./ ( 1 - 2 * tau * T_y ) - T_y./ ( 1 - 2 * tau * T_y );
    f_tmp = mean(fun1_tmp) - 1/(2*tau*delta);
    if f_tmp < 0
        tau_min = tau;
    else
        tau_max = tau;
    end
    if abs(f_tmp) < 1e-3 | (it > 1000)
        break;
    end
    tau = (tau_max + tau_min)/2;    
    it = it + 1;
end

%% compute alpha
phi_hat2 = mean( (delta * abs(z).^2 - 1) .* (2 * tau .* T_y ./ (1-2*tau * T_y) ).^2 );
phi_hat3 = mean( (2 * tau.* T_y ./ (1-2*tau * T_y) ).^2 );

alpha2 = ( 1 - delta * phi_hat3 )/( 1 + delta * phi_hat2 );

if alpha2 < 0
    fprintf('delta below phase transition\n');
    pause;
end

alpha = sqrt(alpha2);


