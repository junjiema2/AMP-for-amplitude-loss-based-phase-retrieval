%% trimming function
% 1. Phase Transitions of Spectral Initialization for High-Dimensional Nonconvex Estimation
% 2. Fundamental Limits of Weak Recovery with Applications to Phase
% Retrieval. (127)

% 'truncation': 
% 'subset':
% 'optimal': 
function ytr = trim(y, Params)

    delta = Params.delta;

%   do pre-processing to normalize E[|Ax|^2] = 1
    yn = y/sum(y) * length(y); % normalized to sum(y) = M. 
    
     % trimming option
    switch Params.init_opt
            
       case 'optimal'
          
          if Params.cplx_flag   % complex-valued
              ytr = (yn - 1)./( yn + sqrt(delta) -1);
          else  % real-valued
              ytr = (yn - 1)./( yn + sqrt(2 * delta) -1);
          end

       case 'truncation'
           ytr = yn.* (yn <= Params.alpha_y^2);   % an overall scaling doesn't impact PCA
       case 'subset'
           ytr = ( yn >= 1.5^2);  
       otherwise
          fprintf('no such initialization option\n');
          % others to be added later
          pause;
    end
 
end