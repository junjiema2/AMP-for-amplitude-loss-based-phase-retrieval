%% state evolution

function SE_results =  StateEvolution(Params,alpha_0,sigma2_0)


delta = Params.delta;
sigma2_w = 1/delta * 10^(-Params.SNRdB/10);  % to be consistent with paper



if strcmp(Params.tau_acurracy,'high')
    MM = 5e6;
elseif strcmp(Params.tau_acurracy,'medium')
    MM = 5e5;
elseif strcmp(Params.tau_acurracy,'low')
    MM = 1e5;
end

%% SE of AMP.A using SE-computed divergence
Alpha_SE = zeros(Params.T,1);
Sigma2_SE = zeros(Params.T,1);
Dif_p_SE = zeros(Params.T,1);

% spectral initialization
alpha = alpha_0;
sigma2 = sigma2_0;

if Params.cplx_flag == 0  % real-valued 

    for it = 1:Params.T

        sigma = sqrt(sigma2);  % be careful!

        % this has lower error floor
        dif_p = 2/(pi) * sigma/( alpha^2 + sigma^2 ) - 1;      
        if alpha > 0
            dif_z = 1 - 2/pi * atan( sigma/alpha );
            g2 = 1/delta * ( (alpha - 1)^2 + sigma2 - 4 * sigma/pi + 4* alpha/pi * atan( sigma/alpha ) );
        else
            dif_z = - 1 - 2/pi * atan(sigma/alpha);
            g2 = 1/delta * ( (alpha + 1)^2 + sigma2 - 4 * sigma/pi + 4* alpha/pi * atan( sigma/alpha ) );
        end
        
        g2 = g2 + sigma2_w;
        
        if ~Params.div_SE & it == 1 % one-step smoothing
            
            z = sqrt(1/delta) * ( randn(MM,1) + 1i * Params.cplx_flag * randn(MM,1) ) / sqrt( 2^Params.cplx_flag );
            w = sqrt(1/delta) * ( randn(MM,1) + 1i * Params.cplx_flag * randn(MM,1) ) / sqrt( 2^Params.cplx_flag );
            p = alpha * z + sqrt(sigma2) * w;  
            y = abs(z);
            
            Smooth_T = Params.Smooth;          
            g = y .* ( max(min(p/Smooth_T,1),-1) ) - p;
            dif_p = mean( y.*( 1/Smooth_T * ( abs(p) < Smooth_T ) ) ) - 1;
            dif_z = mean( sign(z) .* ( max(min(p/Smooth_T,1),-1) ) );
            g2 = mean(abs(g).^2);
            
            g2 = g2 + sigma2_w;
        end

        alpha = dif_z;    
        sigma2 = g2;

        Sigma2_SE(it) = sigma2;
        Alpha_SE(it) = alpha;
        Dif_p_SE(it) = dif_p;

        if sigma2 < 1e-30
            Sigma2_SE(it+1:Params.T) = sigma2;
            Alpha_SE(it+1:Params.T) = alpha;
            Dif_p_SE(it+1:Params.T) = dif_p;
            break;
        end
    end
else  % complex case
    for it = 1:Params.T

        sigma = sqrt(sigma2);  % be careful!
        
        m = alpha^2/sigma^2;
        [K,E] = ellipke(m/(m+1),1e-20);
        test = 2 * 1/m * ( sqrt(m+1) * E - 1/sqrt(m+1) * K );
        alpha_new = alpha / (2 * sigma) * test;

        test2 = 2 *  ( 2 * sqrt(m+1) * E - 1/sqrt(m+1) * K );
        g2_test = 1/delta * ( alpha^2 + sigma2 + 1 - sigma/2 * test2 );
        
        
        sigma2_new = 4 * (g2_test+sigma2_w);
 
        dif_p = E/sqrt(1+m) /(2*sigma) - 1;
        
        alpha = alpha_new;
        sigma2 = max(sigma2_new,1e-50); % prevent negative value due to numerical error
        
        Alpha_SE(it) = alpha_new;
        Sigma2_SE(it) = max(sigma2,1e-50); % prevent negative value due to numerical error
        Dif_p_SE(it) = dif_p;

        if sigma2 < 1e-20
            Sigma2_SE(it+1:Params.T) = sigma2;
            Alpha_SE(it+1:Params.T) = alpha;
            Dif_p_SE(it+1:Params.T) = dif_p;
            break;
        end
        
    end
end

%% update
SE_results.Alpha = Alpha_SE;
SE_results.Sigma2 = Sigma2_SE;
SE_results.Dif_p = Dif_p_SE;