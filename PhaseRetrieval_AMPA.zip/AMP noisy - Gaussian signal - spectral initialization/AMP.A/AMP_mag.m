%% input is magnitude

% suppose we estimate the signal norm using y norm, 

function [Error,SE_out] = AMP_mag(y_mag, x, x0, Params, Amatrix)    

%%

delta = Params.delta;

sigma2_w = 1/delta * 10^(-Params.SNRdB/10);  % to be consistent with paper

n = length(x);

%% initialization
if strcmp(Params.init_opt,'positive')
    alpha_0 = Params.init_scale * sqrt(Params.epsilon);
    sigma2_0 = Params.init_scale^2 - alpha_0^2;
    tau = nan;
else
    [tau,alpha_0] = Spectral_SE(Params);
    sigma2_0 = 1 - alpha_0^2; 
    
    % estimated signal power = 1 + delta * sigma2_w; scale both alpha and
    % sigma2
    alpha_0 = alpha_0 * Params.init_scale;
    sigma2_0 = sigma2_0 * Params.init_scale^2;
    
    y_int = abs(y_mag).^2;
    ytr = trim(y_int, Params); %
end

x_hat = x0; % now x0 is the output of power method

%% state evolution
Results =  StateEvolution(Params,alpha_0,sigma2_0);

SE_out.Alpha = Results.Alpha;
SE_out.Sigma2 = Results.Sigma2;
SE_out.Dif_p = Results.Dif_p;
SE_out.alpha0 = alpha_0;
SE_out.tau = tau;

Error.Alpha = zeros(Params.T,1);
Error.Sigma2 = zeros(Params.T,1);
Error.MSE = zeros(Params.T,1);

%% AMP iterations
% data pre-processing: to be consistent with the normalization used in our
% paper
scaling = sqrt( 1/norm(Amatrix,'fro')^2 * length(x) );

% test
%y = sqrt(y_int) * scaling;
y = y_mag * scaling;

A = Amatrix * scaling;  % E[A_ij^2] = 1/m

x_hat_old = zeros(length(x),1);

for it = 1: Params.T
    %% real
    if Params.cplx_flag == 0  % real-valued 

        if it == 1 
            
            if Params.spectral_correct & ~strcmp(Params.init_opt,'positive') % proposed correction
                p_hat = (1-2*tau * ytr) .* (A * x_hat);
            elseif strcmp(Params.init_opt,'positive')
                p_hat = A * x_hat;  % positive signal
            else
                p_hat = A * x_hat;  % blind approach
            end

            if Params.div_SE
                g = y .* sign(p_hat) - p_hat;
                dif_p = SE_out.Dif_p(it);  % s_hat and x_hat are the previous iteration
            else
                Smooth_T = Params.Smooth;          
                g = y .* ( max(min(p_hat/Smooth_T,1),-1) ) - p_hat;
                dif_p = mean( y.*( 1/Smooth_T * ( abs(p_hat) < Smooth_T ) ) ) - 1;
            end

        else
            p_hat = A * x_hat - 1/delta * s_hat;
            g = y .* sign(p_hat) - p_hat;
            if Params.div_SE
                dif_p = SE_out.Dif_p(it);  % s_hat and x_hat are the previous iteration
            else
                dif_p = 2/pi * sqrt( mean(s_hat.^2) ) / ( mean(x_hat.^2) ) - 1; 
            end
        end
        
        s_hat = g;
        
        x_hat = -dif_p * x_hat + A' * s_hat;
        
    %----------------------------- complex-valued ----------------
    else
        
        if it == 1 
            if Params.spectral_correct & ~strcmp(Params.init_opt,'positive') % proposed correction
                p_hat = (1-2*tau * ytr) .* (A * x_hat);
            elseif strcmp(Params.init_opt,'positive')
                p_hat = A * x_hat;  % positive signal
            else % blinded
                p_hat = A * x_hat;
            end
        else
            p_hat = A * x_hat - 1/delta * 2 * s_hat;
        end
        

        g = ( y - abs(p_hat) ) .* sign(p_hat);
        
        if Params.div_SE
            dif_p = SE_out.Dif_p(it);  % s_hat and x_hat are the previous iteration
        else
            dif_p = mean(0.5 * y./abs(p_hat)) - 1;
        end
        
        s_hat = g;
        x_hat = -2*dif_p * x_hat + 2 * ( A' * s_hat );
        
    end
    
    %% accuracy
    Error.MSE(it) = norm(x - exp(-1i*angle(trace(x'*x_hat))) * x_hat, 'fro')^2/norm(x,'fro')^2;
    Error.Alpha(it) = abs( x'*x_hat/norm(x)^2 ) ;
    Error.Sigma2(it) = norm( x_hat - x'*x_hat/norm(x)^2 * x )^2/norm(x)^2; 
    
    %% stopping condition
    if norm(x_hat - x_hat_old)^2/norm(x_hat)^2 < Params.stop_tol
        Error.MSE(it+1:Params.T) = Error.MSE(it);
        Error.Alpha(it+1:Params.T) = Error.Alpha(it);
        Error.Sigma2(it+1:Params.T) = Error.Sigma2(it);
        break;
    end
    
    x_hat_old = x_hat;

    if Params.show_hist
        fprintf('it = %d\n',it);
        fprintf('simulation: alpha = %e, sigma2 = %e\n',Error.Alpha(it),Error.Sigma2(it));
        if Params.showSE
            fprintf('prediction: alpha = %e, sigma2 = %e\n\n',SE_out.Alpha(it),SE_out.Sigma2(it));
        end
    end

end

